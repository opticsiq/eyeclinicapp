# Model for Patient
class Patient {}