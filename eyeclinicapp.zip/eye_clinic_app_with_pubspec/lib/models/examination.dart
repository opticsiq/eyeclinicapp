# Model for Examination
class Examination {}