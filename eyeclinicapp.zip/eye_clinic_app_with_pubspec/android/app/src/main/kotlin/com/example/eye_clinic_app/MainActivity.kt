package com.example.eye_clinic_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
